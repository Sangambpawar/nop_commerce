import time

import allure
from allure_commons.types import AttachmentType
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from pageobject.login_page_object import  login_nop
from testcases.conftest import getDataforLogin


class Test_login_Parametrized():

    # this is decorater for allure report
    @allure.severity(allure.severity_level.BLOCKER)
    @allure.link("https://demo.nopcommerce.com/login?returnUrl=%2F")
    @allure.title(" Page Title Test Case")
    @allure.issue("test_login_01")
    @allure.story(" This is story#1")
    def test_login_01(self, setup,getDataforLogin):
        self.driver = setup
        self.driver.get('https://demo.nopcommerce.com/login?returnUrl=%2F')
        self.lp = login_nop(self.driver)
        self.lp.email_log_nop_method(getDataforLogin[0])
        self.lp.pass_log_method_nop(getDataforLogin[1])
        self.lp.click_log_nop()


        time.sleep(2)
        if self.lp.login_status_method() == True:
            self.driver.save_screenshot("F:\\nopcommerce_project\\Screenshot\\for_parametrize_login\\test_login_pass.png")
            allure.attach(self.driver.get_screenshot_as_png(), name="Parameterized login test is pass",
                          attachment_type=AttachmentType.PNG)
            assert True
        else:
            self.driver.save_screenshot("F:\\nopcommerce_project\\Screenshot\\for_parametrize_login\\test_login_fail.png")
            allure.attach(self.driver.get_screenshot_as_png(), name="Parameterized login test is fail",
                          attachment_type=AttachmentType.PNG)
            self.lp.click_relogin_method()
            assert False

        self.driver.close()



        #

