import time

import allure
from allure_commons.types import AttachmentType

from pageobject.login_page_object import register_nop, login_nop
from utilities.Logger_register import LogGenerator


class Test_regi_nop_commerce:
    log=LogGenerator().loggen()

    @allure.severity(allure.severity_level.BLOCKER)
    @allure.link("https://demo.nopcommerce.com/register?returnUrl=%2F")
    @allure.title(" Page Title Test Case")
    @allure.issue("test_regi_nop")
    @allure.story(" This is story#1")
    def test_regi_nop(self,setup):

        self.driver=setup
        self.log.info('Test execution of testcase "test_regi_nop is " start')
        self.driver.get('https://demo.nopcommerce.com/register?returnUrl=%2F')
        time.sleep(2)
        self.log.info('register_nop method is called')
        self.lp=register_nop(self.driver)
        time.sleep(2)
        # Enter Gender
        self.log.info('Enter Gender')
        self.lp.gender_male_method()
        time.sleep(2)
        # enter first name
        self.log.info('enter first name')
        self.lp.first_name_regi_method('sangam')
        # enter last name
        self.log.info('enter last name')

        self.lp.last_name_regi_method('pawar')
        time.sleep(2)
        # select dropdown day
        self.log.info('select dropdown day is "28"')
        self.lp.drop_day_method('28')
        # select dropdown month
        self.log.info('select dropdown month is "1"')
        self.lp.drop_mon_method('1')
        # select dropdown year
        self.log.info('select dropdown year is "1997"')
        self.lp.drop_year_method('1997')
        # enter email
        self.log.info('enter email is "sangam1@gmail.com"')
        self.lp.email_regi_method('sangam1@gmail.com')
        self.log.info('enter company name is "Dazzling"')
        # enter company name is "Dazzling"
        self.lp.company_name_method('dazzling')
        # enter password is "123456"
        self.log.info('enter password is "123456"')
        self.lp.password_regi_method('123456')
        # enter confirm password is "123456"
        self.log.info('enter confirm password is "123456"')
        self.lp.con_pass_regi_method('123456')

        time.sleep(3)
        self.lp.click_regi_button_method()
        time.sleep(3)
        # check login status
        self.log.info('check login status')


        if self.lp.regi_status_method()==True:
            # Take a login is pass screenshot
            self.log.info('Take screenshot "test_regi_pass" ')
            allure.attach(self.driver.get_screenshot_as_png(), name="registration is pass",
                          attachment_type=AttachmentType.PNG)

            self.driver.save_screenshot("F:\\nopcommerce_project\\Screenshot\\register\\test_regi_pass.png")
            assert True
            self.driver.close()
        else:
            # Take a login is Fail screenshot
            self.log.info('Take screenshot "test_regi_fail" ')
            self.driver.save_screenshot("F:\\nopcommerce_project\\Screenshot\\register\\test_login_fail.png")
            allure.attach(self.driver.get_screenshot_as_png(), name="registration is fail",
                          attachment_type=AttachmentType.PNG)
            assert False
        self.driver.close()
