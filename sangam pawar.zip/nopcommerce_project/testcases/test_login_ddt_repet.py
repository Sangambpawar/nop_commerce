import time

import allure
from allure_commons.types import AttachmentType

from pageobject.login_page_object_nop import login_nop_ddt
from utilities.Logger_login import LogGenerator
from utilities.XLutils import RowCount, ReadData, WriteData


class Test_login_ddt_repet:
    log = LogGenerator.loggen()

    @allure.severity(allure.severity_level.BLOCKER)
    @allure.link("https://demo.nopcommerce.com/login?returnUrl=%2F")
    @allure.title(" Page Title Test Case")
    @allure.issue("test_login_ddt")
    @allure.story(" This is story#1")
    def test_login_ddt(self,setup):
        self.driver=setup

        # URL
        self.driver.get('https://demo.nopcommerce.com/login?returnUrl=%2F')
        # Start test execution
        self.log.info('Start testcase excecution of test case "test_login_ddt_"')

        # Called "login_nop_ddt" method and driver
        self.lp=login_nop_ddt(self.driver)

        # Read data from excel file this file contained Valid credential and Invalid credential
        self.xl_path='F:\\nopcommerce_project\\Testdata\\login_test_data.xlsx'
        self.log.info('load excel file')

        # count no of rows in a excel file
        self.rowcount=RowCount(self.xl_path,'Sheet1')
        self.log.info('count total row in excel file')



        # create list for store the test result
        self.list1 = []

        # used for loop for inserting data in testcase from excel file
        for i in range(2,self.rowcount+1):
            # read username or email from file
            self.log.info(f'read email from  {i} no row in excel file')
            self.email = ReadData(self.xl_path, 'Sheet1', i, 1)
            # read password from file
            self.log.info(f'read password from {i} no row in  excel file')
            self.password = ReadData(self.xl_path, 'Sheet1', i, 2)
            # enter email or username
            self.log.info('enter username')
            self.lp.email_for_login(self.email)
            # enter password
            self.log.info('enter password')
            self.lp.pass_for_login(self.password)
            # click on login button
            self.log.info('click on login button')
            self.lp.click_login_button()
            # read expected result from excel file
            self.exp = ReadData(self.xl_path, 'Sheet1', i, 5)

            # check login status is pass or failed
            self.log.info('check loggin status')
            if self.lp.login_status()==True:
                self.driver.save_screenshot(f"F:\\nopcommerce_project\\Screenshot\\DDT_Login\\Pass_screenshot_for_{i}_no_input.png")
                allure.attach(self.driver.get_screenshot_as_png(), name="DDT test case is Pass",
                              attachment_type=AttachmentType.PNG)
                # write actual result in excel file
                self.log.info('Write actual result in excel file')
                self.write=WriteData(self.xl_path, 'Sheet1', i, 4,'Pass')

                if self.exp=='Pass':
                    # if login pass and expected result also pass then write Test case  result is 'pass'
                    self.list1.append('Pass')
                 # if login pass and expected result is failed  then write Test case  result is 'fail'
                elif self.exp=='Fail':
                    self.list1.append('Fail')

                # if login is pass then we have click on logout button
                self.log.info('click logout button')
                self.lp.click_logout()
                # click again login button
                self.log.info('click login button after logout')
                self.lp.click_login_again()
            # if login fail then execute else condition
            else:
                self.driver.save_screenshot(f"F:\\nopcommerce_project\\Screenshot\\Fail_screenshot_for_{i}_no_input.png")
                allure.attach(self.driver.get_screenshot_as_png(), name="DDT test case is fail",
                              attachment_type=AttachmentType.PNG)
                self.log.info('Write actual result in excel file')
                self.write = WriteData(self.xl_path, 'Sheet1', i, 4, 'Fail')

                if self.exp=='Fail':
                    # if login is fail and expected result also fail then write Test case  result is 'pass'
                    self.list1.append('Pass')
                elif self.exp=='Pass':
                    # if login failed and expected result is pass then write actual result 'fail'
                    self.list1.append('Fail')
                # click on login button
                self.lp.click_login_again()
        # print result
        self.log.info('Print result')
        print(self.list1)
        # apply assertion if Fail is found in a list then test case failed otherwise pass
        self.log.info('result')
        if 'Fail' not in self.list1:
            assert True
        else:
            assert False

